import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Core } from '../../service/core.service';
import { Observable } from 'rxjs/Observable';
import { ShoppingCartProvider } from '../../providers/shopping-cart/shopping-cart';
import { Storage } from '@ionic/storage';

import { DetailPage } from '../detail/detail';
import { Http } from '@angular/http';
import { Config } from '../../service/config.service';

declare var wordpress_url:string;
declare var wordpress_per_page: Number;
declare var hide_sale: boolean;

@Component({
  selector: 'page-getall-newproduct',
  templateUrl: 'getall-newproduct.html',
    providers: [Core]
})
export class GetallNewproductPage {
	page = 1; products: Object[] = [];
	enpoint:string;
	title:string;
    DetailPage = DetailPage;
	@ViewChild('footer') buttonFooter;
    checkResult:boolean = false;
    cart: Object[] = [];
    currency: any;
    lang: any;
    hide_sale = hide_sale;
    
	constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private core: Core,
        private http: Http,
        private cart_provider: ShoppingCartProvider,
        private config: Config,
        private storage: Storage
    ) {
        core.showLoading();
        this.currency = config['currency']['code'];
        this.lang = config['lang']['language'];
	  	this.enpoint = navParams.get('enpoint');
        this.title = navParams.get('title');
        this.getProducts(this.enpoint).subscribe(products => {
            console.log(products);
            if(products && products.length > 0) {
                this.products = products;
            }
            this.checkResult = true;
            core.hideLoading();
        });
    }
    
    ionViewDidEnter(){
        this.buttonFooter.update_footer();
        this.storage.get('cart').then(res => {
            this.cart = res;
        })
	}

	getProducts(enpoint:string): Observable<Object[]> {
		return new Observable(observable => {
            let params = { post_num_page: this.page, post_per_page: wordpress_per_page,
                woo_currency: this.currency, lang: this.lang};
            let url = '';
           if (enpoint == "hot") {
                url = wordpress_url+'/wp-json/cellstore/static/getproducthots';
            } else {
                url = wordpress_url + '/wp-json/wooconnector/product/'+enpoint;
            }
			this.http.get(url, {
				search: this.core.objectToURLParams(params)
			}).subscribe(products => {
				observable.next(products.json());
				observable.complete();
			});
		});
	}

	doRefresh(refresher) {
        this.page = 1;
        this.core.showLoading();
        this.getProducts(this.enpoint).subscribe(products => {
            // this.products = [];
            if(products && products.length > 0) {
                this.products = products;
            }
            this.core.hideLoading();
        });
        setTimeout(() => {
           refresher.complete();
        }, 200);
    }
    
	load(infiniteScroll) {
        this.page++;
		this.getProducts(this.enpoint).subscribe(products => {
            this.products = this.products.concat(products);
			infiniteScroll.complete();
		});
    }
    
    quickAddCart(product, ele) {
        this.cart_provider.addSimpleToCart(product).subscribe(() => {
            // ele.target.nextSibling.nextElementSibling.classList.add("active");
            this.storage.get('cart').then(res => {
                this.cart = res;
            });
            this.buttonFooter.update_footer();
        }); 
    }
    
    inCart(product_id, cart) {
        return this.cart_provider.inCart(product_id, cart);
    }

}
