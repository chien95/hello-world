import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController,AlertController, Content } from 'ionic-angular';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ShoppingCartProvider } from '../../providers/shopping-cart/shopping-cart';
import { Storage } from '@ionic/storage';

// Custom
import { Core } from '../../service/core.service';
import { Config } from '../../service/config.service';
import { TranslateService } from 'ng2-translate';

//Pipes
import { ObjectToArray } from '../../pipes/object-to-array';
// Page
import { DetailPage } from '../detail/detail';
import { SortpopupPage } from '../sortpopup/sortpopup';
import { SearchPage } from '../search/search';

declare var wordpress_url:string;
declare var wordpress_per_page:Number;
declare var hide_sale: boolean;

@Component({
  selector: 'page-brand',
  templateUrl: 'brand.html',
  providers: [ObjectToArray]
})
export class BrandPage {
	DetailPage = DetailPage;
	SortpopupPage = SortpopupPage;
    SearchPage = SearchPage;
    @ViewChild('search_input') search_input ;
    @ViewChild(Content) content: Content;
	@ViewChild('footer') buttonFooter;
	BrandPage = BrandPage;
	id:Number; name:String; idParent:Number; attr:String; page = 1; sort:string = 'date'; range:Object = {lower:0, upper:0}; 
	checkFilter:boolean = false;
	data:Object = {}; products:Object[] = []; attributes:Object[] = [];
	filter:Object = {grid:true, open:null, value:{}, valueCustom: {}}; filtering:boolean;
	brands:Object[] = []; loaded:boolean; checkFilterPopup:boolean = false;
	checkMenu:boolean = false;
    checkSort: boolean = false;
	chooseCat:Number;
	activeSearch:boolean = false;
	keyword:string = '';
    checkResuilt:boolean = false;
    filter_sale: boolean = false;
    filter_stock: boolean = false;
    filter_new: boolean = false;
    can_load_more: boolean = true;
    cart: Object[] = [];
    currency: any;
    lang: any;
    show_keyboard=false;
    hide_sale = hide_sale;
    dir_mode: string;
    
	constructor(
		private navCtrl: NavController,
		private navParams: NavParams,
		private core: Core,
		private http: Http,
		private config: Config,
		private modalCtrl: ModalController,
		private alertCtrl:AlertController,
        private translate:TranslateService,
        private cart_provider: ShoppingCartProvider,
        private storage: Storage
	) {
        this.lang = config['lang']['language'];
        this.currency = config['currency']['code'];
        this.dir_mode = config['app_settings']['dir'];
	  	this.id = navParams.get('id');
	  	this.name = navParams.get('name');
        this.search();
        this.loadBrands();
        http.get(wordpress_url+'/wp-json/wooconnector/product/getattribute')
            .subscribe(res => {
                this.attributes = res.json();
                this.attributes['custom'] = new ObjectToArray().transform(this.attributes['custom']);
                this.reset();
            });
    }
    
	ionViewDidEnter(){
        this.buttonFooter.update_footer();
        this.storage.get('cart').then(res => {
            this.cart = res;
        })  
	}

	loadBrands(){
		let params = {post_num_page:1, post_per_page:100, parent: this.id, lang: this.lang };
		 this.http.get(wordpress_url + '/wp-json/wooconnector/product/getbrands', {
		 	search:this.core.objectToURLParams(params)
		}).subscribe(res => {
			if (res.json() != null){
				this.brands = this.brands.concat(res.json());
			}
			if(this.brands.length == 100){
				params.post_num_page++;
				this.loadBrands();
			}
		});
    };

    getProducts():Observable<Object[]>{
		return new Observable(observable => {
			let tmpFilter = [];
			for (var filter in this.filter['value']) {
				let attr = this.filter['value'][filter];
				if (Object.keys(attr).length > 0) for (var option in attr) {
					if(option != 'select' && attr[option]) {
						let now = {};
						now['keyattr'] = filter;
						now['valattr'] = option;
						now['type'] = 'attributes';
						tmpFilter.push(now);
					}
				};
			}
			for (var filter in this.filter['valueCustom']) {
				let attr = this.filter['value'][filter];
				if (attr && Object.keys(attr).length > 0) for (var option in attr) {
					if(option != 'select' && attr[option]) {
						let now = {};
						now['keyattr'] = filter;
						now['valattr'] = option;
						now['type'] = 'custom';
						tmpFilter.push(now);
					}
				};
            }

            let params = {};
            params['post_num_page'] = this.page;
            params['post_per_page'] = wordpress_per_page;
            params['brand'] = this.id.toString();
            params['status'] = 'publish';
            if (this.keyword) params['search'] = this.keyword                                                                                                                                   ;
            if(this.range['lower'] != 0) params['min_price'] = this.range['lower'];
            if(this.range['upper'] != 0) params['max_price'] = this.range['upper'];
            if(tmpFilter.length > 0) {
                params['attribute'] = JSON.stringify(tmpFilter);                                                                                                                                                            
            }                                   
            if(this.filter_sale){
                params['on_sale'] = 1;
            }
            if(this.filter_stock) {         
                params['in_stock'] = 1;
            }
            if(this.filter_new) {
                params['arrival'] = 1;
            }
            params = this.core.addSortToSearchParams(params, this.sort);
            params['woo_connector'] = this.currency;
            params['lang'] = this.lang;
            this.http.get(wordpress_url+'/wp-json/wooconnector/product/getproductbyattribute', {
                search:this.core.objectToURLParams(params)
            }).subscribe(products => {
                var results = products.json();
                if(this.filter_new) {
                    var i;
                    var tmp = [];
                    for(i=0; i<results.length; i++) {
                        let time = (new Date().getTime() - new Date(results[i]["date_modified_gmt"]).getTime())/1000;
                        if ((time/86400) <= 1)  {
                            tmp.push(results[i]);
                        } 
                    }
                    observable.next(JSON.parse(JSON.stringify(tmp)));
                }  else {
                    observable.next(results);
                }
  
                observable.complete();
            });
		});
	}
    

    reset(){
        this.filter_sale = false;
        this.filter_stock = false;
        this.filter_new = false;
        this.filter['value'] = {};
        if(this.attributes['attributes']) {
            this.attributes['attributes'].forEach(attr => {
                this.filter['value'][attr['slug']] = {};
                this.filter['value'][attr['slug']]['select'] = [];
            });
        }
        if(this.attributes['custom']) {
            this.attributes['custom'].forEach(attr => {
                this.filter['value'][attr['slug']] = {};
                this.filter['value'][attr['slug']]['select'] = [];
            });
        }
		this.range = {lower:0, upper:0};
    }

    load(infiniteScroll){
        this.getProducts().subscribe(products => {
            if (products.length > 0){
                this.page++;
                this.products = this.products.concat(products);
            } else {
                this.can_load_more = false;
            }
            infiniteScroll.complete();
        });
	}
    
	doRefresh(refresher){
        this.search();
		setTimeout(() => { refresher.complete(); }, 200);
    }

    // loadProducts() {
    //     this.page = 1;
    //     this.can_load_more = true;
    //     this.checkResuilt = false;
    //     this.checkFilter = false;
    //     this.core.showLoading();
    //     this.getProducts().subscribe(products => {
    //         this.core.hideLoading();
    //         if(products.length > 0) {
    //             this.page++;
    //             this.products = products;
    //         } else {
    //             this.products = [];
    //             this.checkResuilt = true;
    //         }
    //     });	
    // }
    
	showSort(string:string){
        this.checkFilter = false;
        this.checkMenu = false;
        this.checkSort = true;
		let modal = this.modalCtrl.create(SortpopupPage, {sort:this.sort});
		modal.onDidDismiss(data => {
			if (data && this.sort != data) {
                this.sort = data;
                // this.content.scrollToTop();
                this.search();
            };
            this.checkSort = false;
		});
		modal.present();
	}

	showFilter(){
		if (this.checkFilter){
			this.checkFilter = false;
		} else {
            this.checkFilter = true;
            this.checkMenu = false;
		}
	}
	showMenu(){
		if (this.checkMenu){
			this.checkMenu = false;
		} else {
            this.checkMenu = true;
            this.checkFilter = false;
		}
	}

	searchclick(){
		if(!this.activeSearch){
            this.activeSearch = true;
            setTimeout(() => {
                this.search_input.setFocus();
              },150);
		} else {
			this.activeSearch = false;
		}
    }
    
    search(has_filter: boolean = false){
		// if (this.keyword){ 
            this.page = 1;
            this.can_load_more = true;
            this.checkResuilt = false;
            if(!has_filter) {
                this.reset();
            }
            this.checkFilter = false;
			this.core.showLoading();
			this.getProducts().subscribe(products => {
                this.activeSearch = false;
				this.core.hideLoading();
				if(products.length > 0) {
					this.page++;
					this.products = products;
				} else {
					this.products = [];
					this.checkResuilt = true;
                }
                this.content.scrollToTop();
			});	
		// }
    } 

    quickAddCart(product, ele) {
        this.cart_provider.addSimpleToCart(product).subscribe(() => {
            // ele.target.nextSibling.nextElementSibling.classList.add("active");
            this.storage.get('cart').then(res => {
                this.cart = res;
            });
            this.buttonFooter.update_footer();
        }); 
    }
    
    inCart(product_id, cart) {
        return this.cart_provider.inCart(product_id, cart);
    }

    checkFilterValue(attr_slug, term_name, check_value) {
        if(check_value) {
            this.filter['value'][attr_slug]['select'].push(term_name);
        } else {
            var index = this.filter['value'][attr_slug]['select'].indexOf(term_name);
            this.filter['value'][attr_slug]['select'].splice(index, 1);
        }
    }
}
