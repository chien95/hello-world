import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Config } from '../../service/config.service';

@Component({
  selector: 'page-privacy',
  templateUrl: 'privacy.html',
})
export class PrivacyPage {
  private privacy;

  constructor(public navCtrl: NavController, 
  	public navParams: NavParams,  
  	private config: Config) {
    this.privacy = config['text_static'];
  }


}
