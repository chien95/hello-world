import { Component } from '@angular/core';
import { NavController, AlertController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ScreenOrientation } from '@ionic-native/screen-orientation';

import { Storage } from '@ionic/storage';
import { TranslateService } from 'ng2-translate';
import { Toast } from '@ionic-native/toast';
import { Core } from '../../service/core.service';
import { CoreValidator } from '../../validator/core';

declare var wordpress_url;
@Component({
  selector: 'page-forgot',
  templateUrl: 'forgot.html',
  providers: [Core]
})
export class ForgotPage {
	wordpress_user:string = wordpress_url+'/wp-json/mobiconnector/user/forgot_password';
	formForgot: FormGroup;
    trans:Object = {};
    submitAttempt = false;
    username_not_exist = false;
    keyboard_show = false;

    constructor(
  		private formBuilder: FormBuilder,
		private http: Http,
		private core: Core,
		private storage: Storage,
		private navCtrl: NavController,
		private alertCtrl: AlertController,
		translate: TranslateService,
		private Toast: Toast,
        private navParams : NavParams,
        private screenOrientation: ScreenOrientation
  	) {
        this.formForgot = formBuilder.group({
            username: ['', CoreValidator.required]
        });
        translate.get('login').subscribe(trans => { if(trans) this.trans = trans; });
    }

    backPage(){
        this.navCtrl.pop();
    }

    forgot(){
        this.submitAttempt = true;
        if(!this.formForgot.invalid) {
            this.core.showLoading();
            let params = {username: this.formForgot.value.username};
            this.http.post(wordpress_url+'/wp-json/mobiconnector/user/forgot_password', params
            ).subscribe(res => {
                this.core.hideLoading();
                this.navCtrl.pop();
                this.core.showToastBottom(this.trans["forgot_success"]);
            }, err => {
                console.log(err);
                this.core.hideLoading();
                if(err.json()['code'] == "user_not_exists") {
                    this.username_not_exist = true;
                }
            });
        }
    }
  	
}
