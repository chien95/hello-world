import { Component, ViewChild} from '@angular/core';
import { NavController, ModalController, NavParams, AlertController} from 'ionic-angular';

// Custom
import { Storage } from '@ionic/storage';
import { StorageMulti } from '../../service/storage-multi.service';
import { CurrencyPage } from '../currency/currency';
import { LanguagePage } from '../language/language';
import { TranslateService } from 'ng2-translate';
import { Core } from '../../service/core.service';
import { Config } from '../../service/config.service';
import { OneSignal } from '@ionic-native/onesignal';
import { Http } from '@angular/http';
import { HomePage } from '../home/home';
import { ToastController } from 'ionic-angular';
import { AccountPage } from '../account/account';

declare var wordpress_url:string;
declare var wordpress_per_page: Number;

@Component({
  selector: 'page-setting',
  templateUrl: 'setting.html',
  providers: [StorageMulti, Core]
})
export class SettingPage {
    AccountPage = AccountPage;
    CurrencyPage = CurrencyPage;
    LanguagePage = LanguagePage;
    HomePage = HomePage;
    data: any = {};
	@ViewChild('footer') buttonFooter;
	isCache: boolean;
    // total_cart:number;
    currency: Object = {};
    listCurrency: Object[] = [];
    trans:Object = {};
    listLanguage: Object[] = [];
    lang: Object = {};

  	constructor(
  		public navCtrl: NavController,
  		public navParams: NavParams,
  		private storage: Storage,
  		private storageMul: StorageMulti,
  		private alertCtrl: AlertController,
  		private translate: TranslateService,
  		private config: Config,
        private core: Core,
        private http: Http, 
        private oneSignal: OneSignal,
        private modalCtrl: ModalController,
        private toastCtrl: ToastController,
  		) {
            translate.get('setting.text_size').subscribe(trans => { if(trans) this.trans = trans; });
            this.getData();
      }

    ionViewDidEnter() {
        this.buttonFooter.update_footer();
        if(this.isCache) {
            this.getData();
        } else this.isCache = true;
    }

    goToCurrency(){
        let modal = this.modalCtrl.create(CurrencyPage,
            {active: this.currency['code'], list: this.listCurrency});
        modal.onDidDismiss(data => {
            if(data) {
                this.currency = data;
            }
        });
        modal.present();
    }

    changeStatic(){
        this.core.showLoading();
        this.http.get(wordpress_url+'/wp-json/cellstore/static/gettextstatic?lang='+this.config['lang']['language']).subscribe(
            res => {
                this.core.hideLoading();
                this.config.set('text_static', res.json()['text_static']);
                // this.navCtrl.setRoot(HomePage);  
            }, 
            err => this.core.hideLoading()
        )
    }

    goToLanguage(){
        let modal = this.modalCtrl.create(LanguagePage,
            {active: this.config['lang']['language'], list: this.listLanguage});
        modal.onDidDismiss(data => {
            if(data) {
                this.lang = this.config['lang'];
                this.changeStatic();
            }
        });
        modal.present();
    }

    clearCache() {
        let msg = {};
        this.translate.get('setting')
            .subscribe(trans => { msg = trans; });
        let alert = this.alertCtrl.create({
            message: msg['clear_cache_title'],
            cssClass: 'alert-clear-cache',
            buttons: [
                {
                    text: msg['no'],
                    role: 'cancel',
                    handler: () => {}
                },
                {
                    text: msg['yes'],
                    handler: () => {
                        this.storage.clear().then(() => {
                            this.storage.set('lang_previous', this.config['lang']);
                            this.config['lang'] = this.config['base_lang'];
                            this.storage.set('lang', this.config['lang']);
                            this.translate.use(this.config['lang']['language']);
                            this.storage.set('currency_previous', this.config['currency']);
                            this.config['currency'] = this.config['base_currency'];
                            this.storage.set('currency', this.config['base_currency']);
                            console.log(this.currency);
                            this.updateTextSize('normal');
                            this.getData();
                            this.buttonFooter.update_footer()
                            this.changeStatic();
                            this.core.showToastBottom(msg['clear_success']);
                        });
                    }
                }
            ]
            });
            alert.present();
    }

  	getData(){
        this.storage.get('notification').then(res => {
            if(res || res == false) {
                this.data["notification"] = res;
            } else {
                this.storage.set('notification', true);
                this.data["notification"] = true;
            }
        });
        this.storage.get('text').then(res => {
            if(res) {
                console.log(res);
                this.data["text"] = this.trans['option'][res];
            }  else {
                this.storage.set('text', "normal");
                this.data["text"] = this.trans['option']['normal'];
            }
        });
        this.currency = this.config['currency'];
        // this.storage.get('currency').then(res => {
        //     this.currency =  res; 
        // });
        this.listCurrency = this.config['list_currency'];
        this.lang = this.config['lang'];
        this.listLanguage = this.config['list_lang'];   
      }
      
  	notification(value) {
		this.storage.set('notification', value).then(() => {
			this.oneSignal.setSubscription(value);
		});
    }
    
	changeTextSize() {
        let alert = this.alertCtrl.create({
            cssClass: 'alert-text-size'
        });
        for (let option in this.trans["option"]) {
            let opt = this.trans["option"][option];
            let style = 'alert-option';
            if(opt == this.data.text) {
                style += ' active';
            }
            alert.addButton({
                text: opt,
                cssClass: style,
                handler: () => { this.updateTextSize(option) }
            });
        }
        alert.addButton({
            text: this.trans['cancel'],
            cssClass: 'alert-cancel',
            role: 'cancel',
            handler: () => {}
        });
        alert.present();
    }
    
	updateTextSize(option: string) {
		this.storage.set('text', option);
		let html = document.querySelector('html');
		html.className = option;
		this.data["text"] = this.trans["option"][option];
    }

	onSwipeContent(e) {
		if (e['deltaX'] > 150) this.navCtrl.push(this.AccountPage);
	}
}
