import { Component } from '@angular/core';
import { ContactusPage } from '../contactus/contactus';
import { Config } from '../../service/config.service';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-aboutus',
  templateUrl: 'aboutus.html',
})
export class AboutusPage {
    ContactusPage = ContactusPage;
    textStatic: Object ={};
    constructor(private navCtrl: NavController, private navParams: NavParams,
      	private config: Config ) {
        this.textStatic = config['text_static'];
    }
}