import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';
import { Http } from '@angular/http';
import { StorageMulti } from '../../service/storage-multi.service';
// Custom
import { Core } from '../../service/core.service';
import { Storage } from '@ionic/storage';
import { TranslateService } from 'ng2-translate';

declare var wordpress_url:string;
declare var wordpress_per_page:Number;

@Component({
  selector: 'page-ordercategory',
  templateUrl: 'ordercategory.html',
  providers: [Core, StorageMulti]
})
export class OrdercategoryPage {
	id:Number;
	parents:Object[] = [];
	defaultCategories:Object;
	catName:string;
	trans: any;

	constructor(
		public navCtrl: NavController,
		public navParams: NavParams,
		private http: Http,
		private core: Core,
		private viewCtrl: ViewController,
		private storage: Storage,
		private storageMulti: StorageMulti,
		public translate: TranslateService
		) {
		translate.get('home.all').subscribe(trans => {
            if(trans) this.trans = trans;
        });
        this.parents = navParams.get('categoriesList');
		this.storage.get('idCategoriesDefault').then(value => {
			if (value){
				this.defaultCategories = value;
			} else {
				this.defaultCategories = 0;
			}
		});
	}
	getData(){
		this.storage.set('idCategoriesDefault', this.defaultCategories).then(() => {
			if (this.defaultCategories == 0){
				this.storage.set('cateName', this.trans).then(() => {
					this.viewCtrl.dismiss({id:this.defaultCategories, name: this.catName });
				});
			} else {
				this.parents.forEach(cate =>{
					if (cate['id'] == this.defaultCategories){
						this.catName = cate['name'];
						this.storage.set('cateName', cate['name']).then(() => {
							this.viewCtrl.dismiss({id:this.defaultCategories, name: this.catName });
						});
					}
				});
			}
		});

	}
	dismiss(reload:boolean = false){
		this.viewCtrl.dismiss(reload);
    }
}
