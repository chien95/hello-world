import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Config } from '../../service/config.service';

@Component({
  selector: 'page-term',
  templateUrl: 'term.html'
})
export class TermPage {
    private static_text;
    
    constructor(public navCtrl: NavController, 
    	public navParams: NavParams,  
    	private config: Config) {
        this.static_text = config['text_static'];
    }
}
