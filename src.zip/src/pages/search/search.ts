import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController, Content } from 'ionic-angular';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { TextInput } from 'ionic-angular';
import { ShoppingCartProvider } from '../../providers/shopping-cart/shopping-cart';
import { TranslateService } from 'ng2-translate';

// Custom
import { Core } from '../../service/core.service';
import { Config } from '../../service/config.service';
import { Storage } from '@ionic/storage';

//Pipes
import { ObjectToArray } from '../../pipes/object-to-array';

// Page
import { DetailPage } from '../detail/detail';
import { AccountPage } from '../account/account';
import { SortpopupPage } from '../sortpopup/sortpopup';
import { DetailcategoryPage } from '../detailcategory/detailcategory';

declare var wordpress_url:string;
declare var wordpress_per_page:Number;
declare var hide_sale: boolean;

@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
  providers: [Core]
})
export class SearchPage {
    @ViewChild(Content) content: Content;
	// @ViewChild(TextInput) inputSearch: TextInput;
	@ViewChild('footer') buttonFooter;
	DetailPage = DetailPage;
	AccountPage = AccountPage;
    SortpopupPage = SortpopupPage;
    DetailcategoryPage = DetailcategoryPage;
	keyword:string = '';
	products:Object[] = []; attr:String; range:Object = {lower:0, upper:0}; attributes:Object[] = [];
	filter:Object = {grid:true, open:null, value:{}}; filtering:boolean; tmpFilter:Object[];
	page = 1;
    sort:string = 'date';
    checkMenu: boolean = false;
	checkFilter:boolean = false;
	checkResuilt = false;
    checkSort = false;
	grid:boolean = true;
    favorite:Object = {};
    categories: Object[] = [];
    filter_sale: boolean = false;
    filter_stock: boolean = false;
    filter_new: boolean = false;
    can_load_more: boolean = true;
    cart: Object[] = [];
    currency: any;
    lang: any;
    show_keyboard = false;
    hide_sale = hide_sale;
    dir_mode: string;
    selected_cate = {};
    trans = {};
    search_all_cate = true;

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
  	private http: Http,
	private core: Core,
	private modalCtrl: ModalController,
    private config: Config,
    private translate: TranslateService,
    private cart_provider: ShoppingCartProvider,
    private storage: Storage
	){
        this.lang = config['lang']['language'];
        this.currency = config['currency']['code'];
        this.dir_mode = config['app_settings']['dir'];
        let key = navParams.get('key');
        this.keyword = key;
        this.search();
        translate.get('search').subscribe(trans => {this.trans = trans});
        console.log(this.selected_cate[0]);

        this.getcategories();
        http.get(wordpress_url+'/wp-json/wooconnector/product/getattribute?woo_currency='+this.currency+'&lang='+this.lang)
            .subscribe(res => {
                this.attributes = res.json();
                this.attributes['custom'] = new ObjectToArray().transform(this.attributes['custom']);
                this.reset();
            });
    }

    ionViewDidEnter() {
        this.buttonFooter.update_footer();
        this.storage.get('cart').then(res => {
            this.cart = res;
        });

    }

  //   ngOnInit(){
		// if(this.inputSearch){
		// 	this.inputSearch["clearTextInput"] = ():void => {
		// 		(void 0);
		// 		this.inputSearch._value = '';
		// 		this.inputSearch.onChange(this.inputSearch._value);
		// 		this.inputSearch.writeValue(this.inputSearch._value);
		// 		setTimeout(() => { this.inputSearch.setFocus(); }, 0);
		// 	}
		// }
  //   }
    
    backPage() {
        this.navCtrl.pop();
    }

    updateCategory(category_id, $event) {
        if(!$event.checked && category_id==0) {
            this.search_all_cate = true;
        } else if ($event.checked && category_id==0) {
            this.search_all_cate = false;
        }
        if(!$event.checked && category_id!=0) {
            delete this.selected_cate[category_id];
        } else if($event.checked && category_id!=0) {
            this.selected_cate[category_id] = category_id;
        } 
        console.log(this.selected_cate);
    }
      
    // get parent category 
    getcategories(){
        let all = 
        this.categories.push({'id': 0, 'name': this.trans['all']})
        let params = {per_page:200, page:1, lang: this.lang};
        let loadCategories = () => {
           this.http.get(wordpress_url + '/wp-json/wooconnector/product/getcategories', {
            search: this.core.objectToURLParams(params)
        }).subscribe(res => {
                this.categories = this.categories.concat(res.json());
                if(res.json().length == 100){
                    params.page++;
                    loadCategories();
                }
                console.log(this.categories);
            });
        };
        loadCategories();
    }

  	reset(){
        this.filter_sale = false;
        this.filter_stock = false;
        this.filter_new = false;
        this.filter['value'] = {};
        if(this.attributes['attributes']) {
            this.attributes['attributes'].forEach(attr => {
                this.filter['value'][attr['slug']] = {};
                this.filter['value'][attr['slug']]['select'] = [];
            });
        }
        if(this.attributes['custom']) {
            this.attributes['custom'].forEach(attr => {
                this.filter['value'][attr['slug']] = {};
                this.filter['value'][attr['slug']]['select'] = [];
            });
        }
		this.range = {lower:0, upper:0};
    }

	search(has_filter: boolean = false){
		if (this.keyword){ 
            this.page = 1;
            this.can_load_more = true;
            this.checkResuilt = false;
            this.checkFilter = false;
            this.checkMenu = false;
            if(!has_filter) {
                this.reset();
            }
			this.core.showLoading();
			this.getProducts().subscribe(products => {
                this.core.hideLoading();
				if(products.length > 0) {
					this.page++;
                    this.products = products;
				} else {
					this.products = [];
					this.checkResuilt = true;
                }
                this.content.scrollToTop();
			});	
		}
    }

	getProducts():Observable<Object[]>{
		return new Observable(observable => {
			let tmpFilter = [];
			for (var filter in this.filter['value']) {
				let attr = this.filter['value'][filter];
				if (Object.keys(attr).length > 0) for (var option in attr) {
					if(option != 'select' && attr[option]) {
						let now = {};
						now['keyattr'] = filter;
						now['valattr'] = option;
						now['type'] = 'attributes';
						tmpFilter.push(now);
					}
				};
			}
			for (var filter in this.filter['valueCustom']) {
				let attr = this.filter['value'][filter];
				if (attr && Object.keys(attr).length > 0) for (var option in attr) {
					if(option != 'select' && attr[option]) {
						let now = {};
						now['keyattr'] = filter;
						now['valattr'] = option;
						now['type'] = 'custom';
						tmpFilter.push(now);
					}
				};
            }
            let params = {};
            params['post_num_page'] = this.page;
            params['post_per_page'] = wordpress_per_page;
            params['status'] = 'publish';
            if (this.keyword) params['search'] = this.keyword;
            if(this.range['lower'] != 0) params['min_price'] = this.range['lower'];
            if(this.range['upper'] != 0) params['max_price'] = this.range['upper'];
            if(tmpFilter.length > 0) {
                params['attribute'] = JSON.stringify(tmpFilter);
            }
            if(this.filter_sale){
                params['on_sale'] = 1;
            }
            if(this.filter_stock) {
                params['in_stock'] = 1;
            }
            if(this.filter_new) {
                params['arrival'] = 1;
            }
            params = this.core.addSortToSearchParams(params, this.sort);
            let cate = [];
            let obj;
            for(obj in this.selected_cate) {
                if(this.selected_cate.hasOwnProperty(obj)) {
                    cate.push(this.selected_cate[obj]);
                }
            }

            if(cate.length > 0 && !this.search_all_cate) {
                params['array_cat'] = '[' + cate.join() + ']';
                console.log(params['array_cat']);
            }
            params['woo_currency'] = this.currency;
            params['lang'] = this.lang;
            this.http.get(wordpress_url+'/wp-json/wooconnector/product/getproductbyattribute', {
                search:this.core.objectToURLParams(params)
            }).subscribe(products => {
                var results = products.json();
                if(results) {
                    observable.next(results);
                }
                observable.complete();
            });
		});
    }

    doRefresh(refresher){
        this.search();
		setTimeout(() => { refresher.complete(); }, 200);
    }
    
	load(infiniteScroll){
        this.getProducts().subscribe(products => {
            if (products.length > 0){
                this.page++;
                this.products = this.products.concat(products);
            } else {
                this.can_load_more = false;
            }
            infiniteScroll.complete();
        });
    }
    
	showSort(){
        this.checkFilter = false;
        this.checkMenu = false;
        this.checkSort = true;
		let modal = this.modalCtrl.create(SortpopupPage, {sort:this.sort});
		modal.onDidDismiss(data => {
			if (data && this.sort != data) {
                this.sort = data;
                // this.content.scrollToTop();
                this.search();
            };
            this.checkSort = false;
		});
		modal.present();
    }
    
	showFilter(){
		if (this.checkFilter){
			this.checkFilter = false;
		} else {
            this.checkFilter = true;
            this.checkMenu = false;
		}
	}

    showMenu(){
		if (this.checkMenu){
			this.checkMenu = false;
		} else {
            this.checkMenu = true;
            this.checkFilter = false;
		}
    }

    quickAddCart(product, ele) {
        this.cart_provider.addSimpleToCart(product).subscribe(() => {
            // ele.target.nextSibling.nextElementSibling.classList.add("active");
            this.storage.get('cart').then(res => {
                this.cart = res;
            });
            this.buttonFooter.update_footer();
        }); 
    }
    
    inCart(product_id, cart) {
        return this.cart_provider.inCart(product_id, cart);
    }

    checkFilterValue(attr_slug, term_name, check_value) {
        if(check_value) {
            this.filter['value'][attr_slug]['select'].push(term_name);
        } else {
            var index = this.filter['value'][attr_slug]['select'].indexOf(term_name);
            this.filter['value'][attr_slug]['select'].splice(index, 1);
        }
    }
}
