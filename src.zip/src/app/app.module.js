var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule, Http } from '@angular/http';
// Module
import { TranslateModule, TranslateLoader, TranslateStaticLoader } from 'ng2-translate';
export function createTranslateLoader(http) {
    return new TranslateStaticLoader(http, './assets/i18n', '.json');
}
import { IonicStorageModule } from '@ionic/storage';
import { TimeAgo } from '../pipes/time-ago';
import { Static } from '../pipes/static';
import { Price } from '../pipes/price';
import { DatePipe } from '@angular/common';
import { Viewmore } from '../pipes/viewmore';
import { ObjectToArray } from '../pipes/object-to-array';
import { ArrayJoin } from '../pipes/array-join';
import { OrderBy } from '../pipes/order-by';
import { Range } from '../pipes/range';
import { Filter } from '../pipes/filter';
//page
import { MyApp } from './app.component';
import { ChildcartComponent } from '../components/childcart/childcart';
import { HomePage } from '../pages/home/home';
import { TermPage } from '../pages/term/term';
import { ForgotPage } from '../pages/forgot/forgot';
import { SignupPage } from '../pages/signup/signup';
import { SigninPage } from '../pages/signin/signin';
import { AddressPage } from '../pages/address/address';
import { CheckoutPage } from '../pages/checkout/checkout';
import { PopoverpagePage } from '../pages/popoverpage/popoverpage';
import { ContactusPage } from '../pages/contactus/contactus';
import { PrivacyPage } from '../pages/privacy/privacy';
import { SortpopupPage } from '../pages/sortpopup/sortpopup';
import { FilterPage } from '../pages/filter/filter';
import { DetailPage } from '../pages/detail/detail';
import { GetallNewproductPage } from '../pages/getall-newproduct/getall-newproduct';
import { CommentPage } from '../pages/comment/comment';
import { AboutusPage } from '../pages/aboutus/aboutus';
import { CartPage } from '../pages/cart/cart';
import { ThankPage } from '../pages/thank/thank';
import { AccountPage } from '../pages/account/account';
import { SettingPage } from '../pages/setting/setting';
import { OrdercategoryPage } from '../pages/ordercategory/ordercategory';
import { FavoritePage } from '../pages/favorite/favorite';
import { OrderPage } from '../pages/order/order';
import { OrderdetailPage } from '../pages/orderdetail/orderdetail';
import { SearchPage } from '../pages/search/search';
import { ProfilePage } from '../pages/profile/profile';
import { ChangepasswordPage } from '../pages/changepassword/changepassword';
import { DetailcategoryPage } from '../pages/detailcategory/detailcategory';
import { RatingPage } from '../pages/rating/rating';
import { Config } from '../service/config.service';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Network } from '@ionic-native/network';
import { OneSignal } from '@ionic-native/onesignal';
import { Camera } from '@ionic-native/camera';
import { SocialSharing } from '@ionic-native/social-sharing';
import { Toast } from '@ionic-native/toast';
import { InAppBrowser } from '@ionic-native/in-app-browser';
// compnent
import { Footer } from '../components/footer/footer';
import { Categories } from '../components/categories/categories';
import { ButtonQuantityComponent } from '../components/button-quantity/button-quantity';
import { HideShowComponent } from '../components/hide-show/hide-show';
// declare var application_package:string;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    NgModule({
        declarations: [
            MyApp,
            HomePage,
            TermPage,
            ForgotPage,
            SignupPage,
            SigninPage,
            PopoverpagePage,
            ContactusPage,
            PrivacyPage,
            Footer,
            RatingPage,
            Categories,
            CartPage,
            AboutusPage,
            AccountPage,
            DetailPage,
            GetallNewproductPage,
            SettingPage,
            OrderPage,
            FilterPage,
            FavoritePage,
            SortpopupPage,
            CheckoutPage,
            ThankPage,
            SearchPage,
            CommentPage,
            ProfilePage,
            Range,
            Filter,
            AddressPage,
            ChangepasswordPage,
            Static,
            ArrayJoin,
            OrderBy,
            TimeAgo,
            Price,
            DetailcategoryPage,
            Viewmore,
            ObjectToArray,
            ButtonQuantityComponent,
            ChildcartComponent,
            HideShowComponent,
            OrderdetailPage,
            OrdercategoryPage
        ],
        imports: [
            BrowserModule,
            IonicModule.forRoot(MyApp, {
                menuType: 'push',
                backButtonText: '',
                backButtonIcon: 'ios-arrow-back',
                mode: 'ios'
            }),
            HttpModule,
            TranslateModule.forRoot({
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [Http]
            }),
            IonicStorageModule.forRoot({ name: 'woocommerkey_wordpress' })
        ],
        bootstrap: [IonicApp],
        entryComponents: [
            MyApp,
            HomePage,
            TermPage,
            ForgotPage,
            AboutusPage,
            SignupPage,
            SigninPage,
            PopoverpagePage,
            ContactusPage,
            ThankPage,
            PrivacyPage,
            Footer,
            DetailPage,
            Categories,
            CartPage,
            AccountPage,
            SettingPage,
            FilterPage,
            OrderPage,
            SortpopupPage,
            FavoritePage,
            CommentPage,
            ProfilePage,
            RatingPage,
            ChangepasswordPage,
            ChildcartComponent,
            AddressPage,
            CheckoutPage,
            SearchPage,
            DetailcategoryPage,
            Categories,
            HideShowComponent,
            GetallNewproductPage,
            OrdercategoryPage,
            OrderdetailPage
        ],
        providers: [
            StatusBar,
            DatePipe,
            SplashScreen,
            Network,
            Config,
            OneSignal,
            SocialSharing,
            Toast,
            Camera,
            InAppBrowser,
            TimeAgo,
            Viewmore,
            { provide: ErrorHandler, useClass: IonicErrorHandler }
        ]
    })
], AppModule);
export { AppModule };
//# sourceMappingURL=app.module.js.map