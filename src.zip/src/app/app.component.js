var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, NgZone, ViewChild } from '@angular/core';
import { Nav, Platform, AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Http } from '@angular/http';
import { Core } from '../service/core.service';
//custom
import { TranslateService } from 'ng2-translate';
import { Storage } from '@ionic/storage';
import { Config } from '../service/config.service';
import { Network } from '@ionic-native/network';
import { OneSignal } from '@ionic-native/onesignal';
import { AdMobFreeBanner, AdMobFreeInterstitial } from '@ionic-native/admob-free';
import { GoogleAnalytics } from '@ionic-native/google-analytics';
//pages
import { HomePage } from '../pages/home/home';
import { DetailcategoryPage } from '../pages/detailcategory/detailcategory';
var MyApp = (function () {
    function MyApp(platform, translate, storage, http, core, config, ngZone, alertCtrl, StatusBar, SplashScreen, OneSignal, Network, banner, interstitial, ga) {
        var _this = this;
        this.platform = platform;
        this.translate = translate;
        this.storage = storage;
        this.http = http;
        this.core = core;
        this.config = config;
        this.ngZone = ngZone;
        this.alertCtrl = alertCtrl;
        this.StatusBar = StatusBar;
        this.SplashScreen = SplashScreen;
        this.OneSignal = OneSignal;
        this.Network = Network;
        this.DetailcategoryPage = DetailcategoryPage;
        this.parents = [];
        this.childs = [];
        this.check_id = [];
        this.check = false;
        this.activeChild = false;
        if (dir_rtl)
            this.dir_rtl_mode = 'right';
        else
            this.dir_rtl_mode = 'left';
        this.DetailcategoryPage = DetailcategoryPage;
        translate.setDefaultLang(application_language);
        translate.use(application_language);
        translate.get('general').subscribe(function (trans) {
            storage.get('login').then(function (login) {
                var params = {};
                if (login && login['token'])
                    params['jwt_token'] = login['token'];
                var getStatic = function () {
                    http.get(wordpress_url + '/wp-json/cellstore/static/gettextstatic', {
                        search: core.objectToURLParams(params)
                    }).subscribe(function (res) {
                        config.set('currency', res.json()['currency']);
                        config.set('text_static', res.json()['text_static']);
                        config.set('check_https', res.json()['check_https']);
                        http.get(wordpress_url + '/wp-json/wooconnector/settings/getactivelocaltion')
                            .subscribe(function (location) {
                            config.set('countries', location.json()['countries']);
                            config.set('states', location.json()['states']);
                            console.log(config);
                            _this.rootPage = HomePage;
                            _this.isLoaded = true;
                            if (res.json()['login_expired']) {
                                storage.remove('login').then(function () {
                                    var alert = alertCtrl.create({
                                        message: trans['login_expired']['message'],
                                        cssClass: 'alert-no-title',
                                        enableBackdropDismiss: false,
                                        buttons: [trans['login_expired']['button']]
                                    });
                                    alert.present();
                                });
                            }
                        }, function () {
                            showAlert();
                        });
                    }, function () {
                        showAlert();
                    });
                };
                getStatic();
                var showAlert = function () {
                    var alert = alertCtrl.create({
                        message: trans['error_first']['message'],
                        cssClass: 'alert-no-title',
                        enableBackdropDismiss: false,
                        buttons: [
                            {
                                text: trans['error_first']['button'],
                                handler: function () {
                                    getStatic();
                                }
                            }
                        ]
                    });
                    alert.present();
                };
            });
        });
        platform.ready().then(function () {
            var admob;
            if (platform.is('android')) {
                admob = {
                    banner: admob_android_banner,
                    interstitial: admob_android_interstitial
                };
            }
            else if (platform.is('ios')) {
                admob = {
                    banner: admob_ios_banner,
                    interstitial: admob_ios_interstitial
                };
            }
            if (admob && admob['banner']) {
                banner.config({
                    id: admob['banner'],
                    overlap: false,
                    autoShow: true,
                    size: 'BANNER'
                });
                banner.prepare();
            }
            if (admob && admob['interstitial']) {
                interstitial.config({
                    id: admob['interstitial'],
                    autoShow: true
                });
                interstitial.prepare();
            }
            if (platform.is('cordova') && google_analytics) {
                ga.startTrackerWithId(google_analytics).then(function () {
                    ga.trackView(platform.is('android') ? 'Android' : 'iOS');
                });
            }
            StatusBar.styleDefault();
            setTimeout(function () {
                SplashScreen.hide();
            }, 100);
            Network.onDisconnect().subscribe(function () {
                ngZone.run(function () { _this.disconnect = true; });
            });
            Network.onConnect().subscribe(function () {
                ngZone.run(function () { _this.disconnect = false; });
            });
        });
        storage.get('text').then(function (val) {
            var html = document.querySelector('html');
            html.className = val;
        });
        this.getcategories();
    }
    MyApp.prototype.getcategories = function (isRefreshing) {
        var _this = this;
        if (isRefreshing === void 0) { isRefreshing = false; }
        var params = { parent: '0', cat_per_page: 100, cat_num_page: 1 };
        var loadCategories = function () {
            _this.http.get(wordpress_url + '/wp-json/wooconnector/product/getcategories', {
                search: _this.core.objectToURLParams(params)
            }).subscribe(function (res) {
                if (isRefreshing) {
                    delete _this.parents;
                    _this.childs = [];
                }
                _this.parents = res.json();
                _this.parents.forEach(function (item, index) {
                    var params1 = { cat_num_page: 1, per_page: 100, parent: item['id'] };
                    _this.http.get(wordpress_url + '/wp-json/wooconnector/product/getcategories', {
                        search: _this.core.objectToURLParams(params1)
                    }).subscribe(function (res) {
                        if (res.json() != null) {
                            // if (this.childs){
                            _this.childs = _this.childs.concat(res.json());
                            _this.activeChild = true;
                            // }
                        }
                    });
                });
                if (res.json().length == 100) {
                    params.cat_num_page++;
                    loadCategories();
                }
            });
        };
        loadCategories();
    };
    MyApp.prototype.doRefresh = function (refresher) {
        this.getcategories(true);
        setTimeout(function () { refresher.complete(); }, 200);
    };
    MyApp.prototype.openPage = function (page, idcat, name, idparent) {
        // Reset the content nav to have just this page
        // we wouldn't want the back button to show in this scenario
        this.nav.push(this.DetailcategoryPage, { id: idcat, name: name, idparent: idparent });
    };
    MyApp.prototype.checkOpen = function (id) {
        if (this.check == false) {
            this.check_id[id] = id;
            if (this.check_id[id] == id) {
                this.check = true;
            }
            else {
                this.check = false;
            }
        }
        else {
            if (this.check_id[id] == id) {
                delete this.check_id[id];
                this.check = false;
            }
            else {
                this.check_id[id] = id;
                this.check = true;
            }
        }
    };
    return MyApp;
}());
__decorate([
    ViewChild(Nav),
    __metadata("design:type", Nav)
], MyApp.prototype, "nav", void 0);
MyApp = __decorate([
    Component({
        templateUrl: 'app.html',
        providers: [Core, AdMobFreeBanner, AdMobFreeInterstitial, GoogleAnalytics]
    }),
    __metadata("design:paramtypes", [Platform,
        TranslateService,
        Storage,
        Http,
        Core,
        Config,
        NgZone,
        AlertController,
        StatusBar,
        SplashScreen,
        OneSignal,
        Network,
        AdMobFreeBanner,
        AdMobFreeInterstitial,
        GoogleAnalytics])
], MyApp);
export { MyApp };
//# sourceMappingURL=app.component.js.map