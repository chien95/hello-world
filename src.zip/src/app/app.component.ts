import { Component, NgZone, ViewChild} from '@angular/core';
import { Nav, Platform, AlertController} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Http } from '@angular/http';
import { Core } from '../service/core.service';
import { LoadingController } from 'ionic-angular';
import { MenuController } from 'ionic-angular';

//custom
import { TranslateService } from 'ng2-translate';
import { Storage } from '@ionic/storage';
import { Config } from '../service/config.service';
import { Network } from '@ionic-native/network';
import { Keyboard } from '@ionic-native/keyboard';
import { ScreenOrientation } from '@ionic-native/screen-orientation';
import { LinkProvider } from '../providers/link/link';

//pages
import { HomePage } from '../pages/home/home';
import { DetailcategoryPage } from '../pages/detailcategory/detailcategory';

declare var wordpress_url:string;

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
    @ViewChild(Nav) nav: Nav;
    rootPage: any;
    trans:Object;
    isLoaded:boolean = false;
    disconnect:boolean = false;
    DetailcategoryPage = DetailcategoryPage;
    parents:Object[] = [];
    childs:Object[]=[];
    id:Number;
    check_id:number[] = [];
    check:boolean = false;
    can_load_more: boolean = true;
    cat_num_page = 1;

  constructor(
        public platform: Platform,
        public translate: TranslateService,
        public storage: Storage,
        public http: Http,
        public core: Core,
        public config: Config,
        public ngZone: NgZone,
        public alertCtrl: AlertController,
        public StatusBar: StatusBar,
        public SplashScreen: SplashScreen,
        public Network: Network,
        private keyboard: Keyboard,
        public loadingCtrl: LoadingController,
        private screenOrientation: ScreenOrientation,
        public menu: MenuController,
        public linkProvider: LinkProvider
    ){
        translate.setDefaultLang('en');    
        this.config['lang'] = {'language': 'en', 'name': 'English'};
       
        platform.ready().then(() => {
            this.keyboard.hideKeyboardAccessoryBar(true);
            this.keyboard.disableScroll(true);
            StatusBar.styleDefault();

            this.getAllSettings();

            Network.onDisconnect().subscribe(() => {
                ngZone.run(() => { 
                    this.disconnect = true; 
                });
            });
            Network.onConnect().subscribe(() => {
                ngZone.run(() => { 
                    this.disconnect = false; 
                });
            });

            this.screenOrientation.onChange().subscribe(
                () => {
                    console.log("Orientation change");
                    let html = document.querySelector('html');
                    if(this.screenOrientation.type.indexOf('portrait') !== -1) {
                        html.classList.remove('landscape-primary');
                        html.classList.remove('landscape');
                    } else {
                        html.classList.remove('portrait-primary');
                        html.classList.remove('portrait');
                    }
                    html.classList.add(this.screenOrientation.type);
                }
            );
        });
    }

    getAllSettings() {
        let url = wordpress_url + "/wp-json/mobiconnector/settings/getfirstloadapp";
        this.http.get(url).subscribe(res => {
                console.log(res.json());
                let settings = res.json();
                this.config['app_settings'] = settings;
                if(settings['application_language']) {
                    console.log(settings);
                    this.config['lang'] = {
                        'language': settings['application_language'], 
                        'name': settings['application_language_name']
                    };
                    this.config['base_lang']  = this.config['lang'];
                }
                this.translate.use(this.config['lang']['language']);
                this.translate.get('general').subscribe(trans => {
                    this.trans = trans;
                });
                this.initialData();
            }, err => {
                this.translate.get('general').subscribe(trans => {
                    this.trans = trans;
                });
                this.SplashScreen.hide();
                this.showNoInternet();
            }
        );
    }

    initialData(){
        let html = document.querySelector('html');
        html.setAttribute("dir", this.config['app_settings']['dir']);
        html.classList.add(this.screenOrientation.type);
        this.storage.get('text').then(res => {
            let html = document.querySelector('html');
            if(res) {
                html.classList.add(res);
            } else {
                html.classList.add('normal');
            }
        });
        this.storage.get('lang').then(res => {
            if(res) {
                this.config['lang'] = res;
                this.translate.use(this.config['lang']['language']);
                this.translate.get('general').subscribe(trans => {
                    this.trans = trans;
                });
            }
            this.storage.get('login').then(login => {
                let params:any = {};
                if(login && login['token']) params['jwt_token'] = login['token'];
                params['lang'] = this.config['lang']['language'];
                let option = {
                    search: this.core.objectToURLParams(params)
                };
                // let headers = new Headers();
                // headers.set('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
                // option['headers'] = headers;
               
                this.http.get(wordpress_url+'/wp-json/cellstore/static/gettextstatic', option).subscribe(
                    res => {
                        console.log(res);
                        let config_tmp = res.json();
                        this.config.set('currency', config_tmp['currency']);
                        this.config['currency']['code'] = this.config['currency']['currency'].toLowerCase();
                        this.config.set('text_static', config_tmp['text_static']);
                        this.config.set('check_https', config_tmp['check_https']);
        
                        this.http.get(wordpress_url+'/wp-json/wooconnector/settings/getactivelocaltion')
                        .subscribe(location => {
                            console.log(location.json());
                            this.config.set('countries', location.json()['countries']);
                            this.config.set('states', location.json()['states']);
                            this.SplashScreen.hide();
                            this.rootPage = HomePage;
                            this.isLoaded = true;
                            this.menu.enable(false);
                            this.getcategories(false);
                            this.getCurrencyList();
                            this.getLanguageList();
                            console.log(this.config);
                            
                            if(config_tmp['login_expired']){
                                this.storage.remove('login').then(() => {
                                    // let alert = this.alertCtrl.create({
                                    //     message: this.trans['login_expired']['message'],
                                    //     cssClass: 'alert-no-title',
                                    //     enableBackdropDismiss: false,
                                    //     buttons: [this.trans['login_expired']['button']]
                                    // });
                                    // alert.present();
                                });
                            }
                        });
                    }, err => {
                        console.log(err);
                    }
                );
            });
        })
       
    }

    showNoInternet() {
        let alert = this.alertCtrl.create({
            message: this.trans['error_first']['message'],
            cssClass: 'alert-no-title',
            enableBackdropDismiss: false,
            buttons: [
              {
                text: this.trans['error_first']['button'],
                handler: () => {
                    this.showLoading();
                }
              }
            ]
        });
        alert.present();
    };

    showLoading(){
        let loading = this.loadingCtrl.create({
            duration: 3000
        });
        loading.onDidDismiss(() => {
            this.getAllSettings();
        });
        loading.present();
    }

    loadCate(infiniteScroll){
        setTimeout(() => {
            this.getcategories();
            infiniteScroll.complete();
          }, 500);
	}

    getcategories(more: boolean = true){
        let params = {parent:'0', cat_per_page:15, cat_num_page: this.cat_num_page, 
            lang: this.config['lang']['language']};
        this.http.get(wordpress_url + '/wp-json/wooconnector/product/getcategories', {
            search: this.core.objectToURLParams(params)
        }).subscribe(res => {
            let parent = res.json();
            if(!more) {
                this.parents = parent;
            } else {
                this.parents = this.parents.concat(parent);
            }
            if(parent.length == 0) {
                this.can_load_more = false;
            }
            let current_cate_index = this.parents.length - parent.length;
            console.log(this.config['lang']['language']);
            for(let i = current_cate_index; i < this.parents.length; i++){
                let params1 = {cat_num_page:1, per_page:100, 
                    parent: this.parents[i]['id'], lang: this.config['lang']['language']};
                this.http.get(wordpress_url + '/wp-json/wooconnector/product/getcategories', {
                    search:this.core.objectToURLParams(params1)
                }).subscribe(res => {
                    this.parents[i]['childs'] = res.json();       
                });
            }
        });
        this.cat_num_page++;
    }

    

    // doRefresh(refresher){
    //     this.getcategories(true);
    //     setTimeout(() => { refresher.complete(); }, 200);
    // }

    openPage(page, idcat, name, idparent) {
        this.nav.push(this.DetailcategoryPage, {id: idcat, name: name, idparent: idparent});
    }

    checkOpen(id:number){
        if(this.check == false) {
            this.check_id[id] = id;
            if (this.check_id[id] == id){
                this.check = true;
            } else {
                this.check =false;
            }
        } else {
            if(this.check_id[id] == id){
                delete this.check_id[id];
                this.check = false;
            } else {
                this.check_id[id] = id;
                this.check =true;
            }
        }
    }

    getCurrencyList() {
        let url = wordpress_url + "/wp-json/wooconnector/settings/getsettingscurrency";
        let params = { post_per_page: 100 };
        this.http.get(url, {
            search: this.core.objectToURLParams(params)
        }).subscribe(
            res => {
                this.config['list_currency'] = res.json()['listcurrency']; 
            },
            err => console.log(err)
        );
    }

    getLanguageList() {
        let url = wordpress_url + "/wp-json/mobiconnector/languages/getlanguages";
        let params = { post_per_page: 300 };
        this.http.get(url, {
            search: this.core.objectToURLParams(params)
        }).subscribe(
            res => {
                this.config['list_lang'] = res.json();
            }, 
            err => console.log(err)
        );
    }
}
